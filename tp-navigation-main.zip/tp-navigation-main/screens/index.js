export { default as HomeScreen } from './HomeScreen';
export { default as DetailsScreen } from './DetailsScreen';
export { default as SettingsScreen } from './SettingsScreen';
